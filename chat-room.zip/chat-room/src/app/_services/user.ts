export class User {
    id: number;
    username: string;
    firstName: string;
    lastName: string;
    email: string;

}
// {"id":1,"username":"wilma","firstName":"Wilma","lastName":"Flintstone","email":"wflintstone@example.com","password":"123456"}
