﻿import { Component, OnInit } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormControl, FormGroup, FormsModule} from '@angular/forms';


import { User } from '../_models';
import { DataService ,} from '../_services';

@Component({ templateUrl: './home.component.html', styleUrls: ['./home.component.css']})
export class HomeComponent implements OnInit {
    currentUser: User;
    users = [];

  messageForm;

    constructor(
      //  private authenticationService: AuthenticationService,
       // private userService: UserService
       private dataService : DataService
    ) {

      this.messageForm = new FormGroup({
        message: new FormControl()
      });
       // this.currentUser = this.authenticationService.currentUserValue;
    }

    

    ngOnInit() {
        this.currentUser = this.dataService.user;
        //this.loadAllUsers();


    }
    sendMessage(){

    }

    deleteUser(id: number) {
        //this.userService.delete(id)
         //   .pipe(first())
         //   .subscribe(() => this.loadAllUsers());
    }

    private loadAllUsers() {
        //this.userService.getAll()
        //    .pipe(first())
        //    .subscribe(users => this.users = users);
    }
}
